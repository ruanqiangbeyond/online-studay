<?php
header("Content-Type: text/cache-manifest");
?>
CACHE MANIFEST
# 2012-12-09 v6
jquery.min.js

NETWORK:
*